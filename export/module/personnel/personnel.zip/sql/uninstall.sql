-- -----------------------------
-- 导出时间 `2018-03-15 08:55:18`
-- -----------------------------
DROP TABLE IF EXISTS `dp_personnel_award`;
DROP TABLE IF EXISTS `dp_personnel_awardcate`;
DROP TABLE IF EXISTS `dp_personnel_care`;
DROP TABLE IF EXISTS `dp_personnel_column`;
DROP TABLE IF EXISTS `dp_personnel_contract`;
DROP TABLE IF EXISTS `dp_personnel_daily`;
DROP TABLE IF EXISTS `dp_personnel_plan`;
DROP TABLE IF EXISTS `dp_personnel_papercat`;
DROP TABLE IF EXISTS `dp_personnel_papers`;
DROP TABLE IF EXISTS `dp_personnel_record`;
DROP TABLE IF EXISTS `dp_personnel_recruit`;
DROP TABLE IF EXISTS `dp_personnel_sign`;
DROP TABLE IF EXISTS `dp_personnel_wage`;
DROP TABLE IF EXISTS `dp_personnel_wagecate`;
DROP TABLE IF EXISTS `dp_personnel_wagelist`;
DROP TABLE IF EXISTS `dp_personnel_work`;
