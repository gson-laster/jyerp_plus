<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/25 0025
 * Time: 15:01
 */

namespace app\finance\model;


use think\Model;

class Finance extends Model
{
    protected $table = '__FINANCE_INFO__';



    public static function getList($map=[], $order=[]){
        $data_list = self::view('finance_info')
            ->view('admin_organization o',['title'=>'detitle'],'o.id=finance_info.depot','left')//供应商
            ->view('admin_user u',['nickname'=>'nanickname'],'u.id=finance_info.name','left')//询价员
            ->view('_tender_obj obj',['name'=>'obj_name'],'obj.id=finance_info.item','left')//采购类别
            ->where($map)
            ->order($order)
            ->paginate();
        return $data_list;
    }
    public static function getOne($id='',$map=[]){
        $data_list = self::view('finance_info i')
            ->view('tender_obj o',['name'=>'oname'],'o.id=i.item','left')//所属项目
            ->view('money_project p',['name'=>'pname'],'p.id=i.project','left')//报销科目
            ->view('admin_organization or',['title'=>'ortitle'],'or.id=i.depot','left')//部门
            ->view('admin_position po',['title'=>'potitle'],'po.id=i.work','left')//职位
            ->view('admin_user u',['nickname'=>'unickname'],'u.id=i.name','left')//报销人
            ->where('i.id',$id)
            ->where($map)
            ->find();
        return $data_list;
    }

}