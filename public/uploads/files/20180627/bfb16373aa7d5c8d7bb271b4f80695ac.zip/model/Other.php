<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/28 0028
 * Time: 14:45
 */

namespace app\finance\model;


use think\Model;

class Other extends Model
{
    protected $table = '__FINANCE_OTHER__';


    public static function getList($map=[], $order=[]){
            $data_list = self::view('finance_other o')
                ->view('dp_tender_obj obj',['name'=>'objname'],'obj.id=o.item','left')//项目
                ->view('admin_user u',['nickname'=>'unickname'],'u.id=o.payer','left')//支付人
                ->view('admin_organization or',['title'=>'ortitle'],'or.id=o.part','left')//部门
                ->view('admin_organization o1',['title'=>'o1rtitle'],'o1.id=o.part','left')//供应商
                ->view('finance_manager m',['accmount'=>'maccount'],'m.id=o.account','left')//账号
                ->view('finance_ptype p',['name'=>'pname'],'p.id=o.ptype','left')//支付类型
                ->view('finance_pway pw',['name'=>'pwname'],'pw.id=o.pway','left')//支付方式
                ->where($map)
                ->order($order)
                ->paginate();
            return $data_list;
        }
}