<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/25 0025
 * Time: 15:53
 */

namespace app\finance\model;




use think\Model;

class Work extends Model
{
    protected $table ='__ADMIN_POSITION__';
}