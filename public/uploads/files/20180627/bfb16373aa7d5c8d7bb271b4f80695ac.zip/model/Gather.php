<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/29 0029
 * Time: 11:00
 */

namespace app\finance\model;
use think\Model;
use think\DB;
class Gather extends Model
{
    protected $table = '__FINANCE_GATHER__';


    public static function getList($map=[], $order=[]){
        $data_list = self::view('finance_gather g')
            ->view('admin_user u',['nickname'=>'uname'],'u.id=g.name','left')//收款人
            ->view('tender_obj obj',['name'=>'sname'],'obj.id=g.supplier','left')//供应商
            ->view('finance_manager m',['accmount'=>'maccount'],'m.id=g.account','left')//公司账户
            ->where($map)
            ->order($order)
            ->paginate();
        return $data_list;
    }


    public static function getSum(){
        $data_list = DB::query('select sum(money) form dp_finance_gather');
        return $data_list;
    }
}