<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/28 0028
 * Time: 15:14
 */

namespace app\finance\model;


use think\Model;

class Ptype extends Model
{
    protected $table = '__FINANCE_PTYPE__';
}