<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/25 0025
 * Time: 17:02
 */

namespace app\finance\model;


use think\Model;

class Standby extends Model
{
    protected $table = '__STANDBY_INFO__';


    public static function getList($map=[], $order=[]){
        $data_list = self::view('standby_info S')
            ->view('admin_organization o',['title'=>'detitle'],'o.id=S.part','left')//部门
            ->view('admin_user u',['nickname'=>'nanickname'],'u.id=S.name','left')//领取人
            ->view('_tender_obj obj',['name'=>'obj_name'],'obj.id=S.item','left')//项目
            ->where($map)
            ->order($order)
            ->paginate();
        return $data_list;
    }


    public static function getOne($id='',$map=[]){
        $data_list = self::view('standby_info S')
            ->view('admin_organization o',['title'=>'detitle'],'o.id=S.part','left')//部门
            ->view('admin_user u',['nickname'=>'nanickname'],'u.id=S.name','left')//领取人
            ->view('_tender_obj obj',['name'=>'obj_name'],'obj.id=S.item','left')//项目
            ->where('S.id',$id)
            ->where($map)
            ->find();
        return $data_list;
    }
}