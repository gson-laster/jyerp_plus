<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/28 0028
 * Time: 10:48
 */

namespace app\finance\model;


use think\Model;

class Bank extends  Model
{
    protected $table = '__FINANCE_MANAGER__';
}