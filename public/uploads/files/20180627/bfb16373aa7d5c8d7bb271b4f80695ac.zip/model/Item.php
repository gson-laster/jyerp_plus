<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/25 0025
 * Time: 15:40
 */

namespace app\finance\model;




use think\Model;

class Item extends Model
{
    protected $table = '__TENDER_OBJ__';
}