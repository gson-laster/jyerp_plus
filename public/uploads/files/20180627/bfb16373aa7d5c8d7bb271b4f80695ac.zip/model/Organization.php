<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/21 0021
 * Time: 14:41
 */

namespace app\finance\model;


use think\Model;

class Organization extends Model
{

    protected $table = '__ADMIN_ORGANIZATION__';
}