<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/28 0028
 * Time: 15:15
 */

namespace app\finance\model;


use think\Model;

class Pway extends Model
{
    protected $table='__FINANCE_PWAY__';

}