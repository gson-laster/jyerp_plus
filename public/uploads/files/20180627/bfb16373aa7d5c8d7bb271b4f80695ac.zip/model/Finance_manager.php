<?php
namespace app\finance\model;

use think\Model as ThinkModel;
use think\Db;

class Finance_manager extends ThinkModel
{
    // 设置当前模型对应的完整数据表名称
    protected $table = '__FINANCE_MANAGER__';
    
    // 自动写入时间戳
    protected $autoWriteTimestamp = true;
	
}
