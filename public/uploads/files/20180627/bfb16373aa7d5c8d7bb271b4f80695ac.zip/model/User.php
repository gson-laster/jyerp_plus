<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/25 0025
 * Time: 15:56
 */

namespace app\finance\model;

use app\finance\model\Organization as OModel;
use think\Model;
class User extends Model
{
    protected $table='__ADMIN_USER__';



    public static function getOne($id=''){
       $data_list= OModel::where('id',$id)->column('title');

        return $data_list;
    }
}