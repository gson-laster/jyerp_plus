<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/25 0025
 * Time: 15:46
 */

namespace app\finance\model;



use think\Model;

class Project extends Model
{
    protected $table = '__MONEY_PROJECT__';
}