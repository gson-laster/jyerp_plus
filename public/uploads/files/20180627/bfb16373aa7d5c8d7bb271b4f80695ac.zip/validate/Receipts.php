<?php
namespace app\common\validate;
use think\Validate;
/**
 * 资产列表验证器
 * @package app\asstes\validate
 * @author HJP
 */
class receipts extends Validate
{
	//定义验证规则
	protected $rule = [
		'date|日期' => 'require',
		'name|收款名称' => 'require',
		'item|项目' => 'require',
		'contract_title|合同名称' => 'require',
		'contract_money|合同金额' => 'require|number',
		'nail|甲方单位' => 'require',
		'gathering_type|收款类型' => 'require',
		'fine|罚款' => 'require',
		'withhold|扣款' => 'require',
		'gathering|收款金额' => 'require|number',
		'big|金额大写' => 'require',
		'operator|填报人' => 'require',
	];
	
	
}
