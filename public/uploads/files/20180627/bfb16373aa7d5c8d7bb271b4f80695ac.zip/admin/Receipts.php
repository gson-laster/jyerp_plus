<?php
namespace app\finance\admin;
use app\admin\controller\Admin;
use app\common\builder\ZBuilder;
use app\finance\model\Finance_receipts as Finance_receiptsmodel;
use app\common\model\Admin_user as user;
use think\Db;
use think\Config;
/*
 *合同收款
 * */
 class Receipts extends Admin {
	protected $model;
	protected $manager;
	protected $bankInfo;
	protected $bankMinInfo;
	protected $gathering_type;
	protected $user;
    protected function _initialize(){
        parent::_initialize();
        $this -> gathering_type = Config::get('pay_type');
        $this -> model = new Finance_receiptsmodel();
        $user = user::select();
        $arr = [];
        foreach($user as $v){
        	$arr[$v['id']] = $v['nickname'];
        }
        $this -> user = $arr;
    }
 	public function index(){
		$map = $this->getMap();
		$data_list = $this->model -> where($map) -> paginate();
		/*
		 *总计
		 */
		$arr = ['gathering' => 0];
		foreach($data_list as $v){
			$arr['gathering'] += $v['gathering'];
		}
			$js = <<<EOF
			   <script type="text/javascript">
                $(function(){
                    $('tbody').append('<tr style="color:#ff0000"><td align="center">总计</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>{$arr['gathering']}</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>');
                });
            </script>
EOF;
		return ZBuilder::make('table')
		  ->addColumns([ // 批量添加列
			[ 'date', '日期', 'date'],
			[ 'number', '收款编号'],
			[ 'name','收款名称'],
			[ 'item','项目'],
			[ 'contract_title','合同名称'],
			[ 'contract_money','合同金额'],
			[ 'nail','甲方单位'],			
			[ 'gathering_type','收款类型', $this -> gathering_type],			
			[ 'fine','罚款'],			
			[ 'withhold','扣款'],			
			[ 'gathering','收款金额'],			
			[ 'big','金额大写'],			
			[ 'operator','填报人'],			
			[ 'note','备注'],			
	        ['create_time', '创建时间', 'datetime'],
	        ['right_button', '操作','btn'],
	    ])
        ->addTopButton('add') // 添加顶部按钮
		->setPageTitle('合同收款')
		->addRightButtons('edit,delete')
		->addTopButton('delete') // 添加顶部按钮
		->setTableName('Finance_receipts') // 指定数据表名
		->setSearch([ 'operator' => '填报人','item'=>'项目名称','contract_title' => '合同名称',  'name' => '收款名称', 'number' => '收款编号', 'nail' => '甲方单位'], '', '', true) // 设置搜索参数
		->addTimeFilter('date') // 添加时间段筛选
		->setExtraJs($js)
		->setRowList($data_list)
		->fetch();
	
 	}
 		public function add(){
		
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'receipts');
			if(true !== $r) $this -> error($r);
			$data['date'] = strtotime($data['date']);
			$data['number'] = 'CGXJ'.date('Ymdhis',time()).UID;
			
			$this-> model -> create($data);
            $this->success('添加成功', 'index');
		}
		
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['date:3', 'date', '日期'],
//			['text:3', 'number', '收款编号'],
			['text:3', 'name','收款名称'],
			['text:3', 'item','项目'],
			['text:3', 'contract_title','合同名称'],
			['text:3', 'contract_money','合同金额'],
			['text:3', 'nail','甲方单位'],			
			['select:3', 'gathering_type','收款类型', '', $this -> gathering_type],			
			['text:3', 'fine','罚款'],			
			['text:3', 'withhold','扣款'],			
			['text:3', 'gathering','收款金额'],			
			['text:3', 'big','金额大写'],			
			['select:3', 'operator','填报人', '', $this -> user, UID],			
			['textarea:12', 'note','备注'],			
		])
		->fetch();
	
	}
	public function edit($id = null){
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'receipts');
			if(true !== $r) $this -> error($r);
			$data['date'] = strtotime($data['date']);
			$this-> model -> where('id', $id) -> update($data);
            $this->success('添加成功', 'index');
		}
		if (null == $id) $this -> error('参数错误');
		$data_list = $this -> model -> where('id', $id) -> find();
		$data_list['date'] = date('Y-m-d', $data_list['date']);
		$data_list['gathering_type'] = $this -> gathering_type[$data_list['gathering_type']];
		
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['static:3', 'date', '日期'],
//			['static:3', 'number', '收款编号'],
			['static:3', 'name','收款名称'],
			['static:3', 'item','项目'],
			['static:3', 'contract_title','合同名称'],
			['static:3', 'contract_money','合同金额'],
			['static:3', 'nail','甲方单位'],			
			['static:3', 'gathering_type', '收款类型'],			
			['static:3', 'fine','罚款'],			
			['static:3', 'withhold','扣款'],			
			['static:3', 'gathering','收款金额'],			
			['static:3', 'big','金额大写'],			
			['static:3', 'operator','填报人'],			
			['static:12', 'note','备注'],
		])
		-> setPageTitle('详情')
		->hideBtn('submit')
		-> setFormData($data_list)
		->fetch();
	
	}
	public function delete($ids = null){
		if(null == $ids) $this -> error('参数错误');
     	return $this->setStatus('delete');
	}
}