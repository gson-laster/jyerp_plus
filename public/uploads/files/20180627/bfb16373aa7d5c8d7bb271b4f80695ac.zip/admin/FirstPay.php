<?php
namespace app\finance\admin;
use app\admin\controller\Admin;
use app\common\builder\ZBuilder;
use app\finance\model\Finance_accmount as Finance_accmountmodel;
use app\finance\model\Finance_manager as Finance_managermodel;
use think\Db;
/*
 *账户期初
 * */
 class FirstPay extends Admin {
	protected $model;
	protected $bankInfo;//银行信息资料
    protected function _initialize(){
        parent::_initialize();
        $this -> model = new Finance_accmountmodel();
        $bank = new Finance_managermodel();
        $arr = $bank -> select();
        $arrs = [];
        foreach($arr as $v) {
        	$arrs[$v['id']] = $v['name'];
        }
        $this -> bankInfo = $arrs;
    }
 	public function index(){
		$map = $this->getMap();
		$data_list = $this->model -> where($map) -> paginate();
		$total = 0;
		foreach($data_list as $v){
			$total += $v['first_money'];
		}
		$js = <<<EOF
			   <script type="text/javascript">
                $(function(){
                    $('tbody').append('<tr style="color:#ff0000"><td align="center">总计</td><td>-</td><td>-</td><td>-</td><td>{$total}</td><td>-</td><td>-</td></tr>');
                });
            </script>
EOF;
		return ZBuilder::make('table')
		  ->addColumns([ // 批量添加列
//	        ['id', 'id'],
	        ['name', '账户昵称', $this -> bankInfo],
	        ['accmount', '账户'],
	        ['bank', '开户银行'],
	        ['first_money', '期初金额'],
//	        ['big_money', '金额大写'],
	        ['operator', '录入人'],
//	        ['create_time', '创建时间', 'datetime'],
	        ['right_button', '操作','btn'],
	    ])
        ->addTopButton('add') // 添加顶部按钮
		->setPageTitle('账户期初')
		->addRightButtons('edit,delete')
		->addTopButton('delete') // 添加顶部按钮
		->setTableName('Finance_accmount') // 指定数据表名
		->setSearch(['accmount' => '账户', 'operator' => '录入人', 'name' => '账户昵称','bank' => '开户银行'], '', '', true) // 设置搜索参数
		->addTimeFilter('create_time') // 添加时间段筛选
		->setExtraJs($js)
		->setRowList($data_list)
		->fetch();
	
 	}
 		public function add(){
		
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'first_pay');
			if(true !== $r) $this -> error($r);
			$this-> model -> create($data);
            $this->success('添加成功', 'index');
		}
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['select:6', 'name', '账户名称', '', $this -> bankInfo],
			['text:6', 'accmount','账户'],
			['text:6', 'bank','开户银行'],
			['number:6', 'first_money','期初金额'],
			['text:6', 'big_money','金额大写'],
			['text:6', 'operator','录入人'],			
		])
		->fetch();
	
	}
	public function edit($id = null){
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'first_pay');
			if(true !== $r) $this -> error($r);
			$this-> model -> where('id', $id) -> update($data);
            $this->success('添加成功', 'index');
		}
		if (null == $id) $this -> error('参数错误');
		$data_list = $this -> model -> where('id', $id) -> find();
		
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['select:6', 'name', '账户名称', '', $this -> bankInfo],
			['text:6', 'accmount','账户'],
			['text:6', 'bank','开户银行'],
			['number:6', 'first_money','期初金额'],
			['text:6', 'big_money','金额大写'],
			['text:6', 'operator','录入人'],	
		])
		-> setFormData($data_list)
		->fetch();
	
	}
	public function delete($ids = null){
		if(null == $ids) $this -> error('参数错误');
     	return $this->setStatus('delete');
	}
}