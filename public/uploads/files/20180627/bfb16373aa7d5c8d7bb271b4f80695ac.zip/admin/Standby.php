<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/25 0025
 * Time: 17:41
 */

namespace app\finance\admin;

use app\admin\controller\Admin;
use app\common\builder\ZBuilder;
use app\finance\model\Standby as StandbyModel;
use app\finance\model\Item as IModel;
use app\finance\model\Organization as OModel;
use app\finance\model\User as UModel;
use app\finance\validate\Standby as StandbyValidate;

class standby extends Admin
{
    public function index(){
        $map = $this->getMap();
        $order = $this->getOrder('s.id desc');
        $data_list = StandbyModel::getList($map,$order);

        //dump($data_list);die;
        //dump($data_list);die;
        //使用ZBuilder构建表格展示数据
        return ZBuilder::make('table')
            ->setSearch(['nickname'=>'领用人','detitle'=>'部门'],'','',true) // 设置搜索框
            ->addTimeFilter('standby_info.time') // 添加时间段筛选
            ->addOrder('number,nanickname,detitle,obj_name,obj_name,money,time') // 添加排序
            ->addColumns([ // 批量添加列
                ['number', '领用单号'],
                ['nanickname', '领用人'],
                ['detitle', '部门'],
                ['obj_name', '项目'],
                ['money', '金额'],
                ['time', '领用日期'],
                ['case', '用途'],
                ['right_button','操作']
            ])
            ->setRowList($data_list) // 设置表格数据
            ->addTopButton('add') //添加删除按钮
            ->addTopButton('delete') //添加删除按钮
            ->addRightButton('edit') // 添加授权按钮
            ->addRightButton('delete') //添加删除按钮
            ->setTableName('standby_info')
            ->fetch();
    }
    public function add(){
        if ($this->request->isPost()) {
            $data = $this->request->post();
            // 验证

//            dump($data);die;
            $result = $this->validate($data, 'Standby');
            // 验证失败 输出错误信息
            if(true !== $result) $this->error($result);
            $data['number'] = 'BYJ'.date('YmdHis',time());
            if ($res = StandbyModel::create($data)) {
                $this->success('新增成功',url('index'));
            } else {
                $this->error('新增失败');
            }
        }
        // 使用ZBuilder快速创建表单
        return ZBuilder::make('form')
            ->setPageTitle('备用金发放')
            ->addFormItems([
                ['date:3','time','日期','',date('Y-m-d')],
                ['select:3','name', '领用人','',UModel::where('status=1')->column('id,nickname')],
                ['select:3','part', '领用部门','',OModel::where('status=1')->column('id,title')],
                ['text:3','year_money','本年领取金额'],
                ['text:3','money','金额'],
                ['select:3','item','所属项目','',IModel::where('status=1')->column('id,name')],
                ['text:3','maker','经办人','',get_nickname(UID)],
                ['textarea','case','用途'],
                ['textarea','remark','备注'],
                ['file','file','附件'],

            ])
            ->fetch();

    }

    public function edit($id = '')
    {

        if ($id === null) $this->error('缺少参数');

        // 保存数据
        if ($this->request->isPost()) {
            $data = $this->request->post();
            $res = StandbyModel::update($data);
            if ($res) {
                $this->success('编辑成功', url('index'));
            } else {
                $this->error('编辑失败');
            }
        }


        $map= $this->getMap();
        $data_list = StandbyModel::getOne($id,$map);

        // 使用ZBuilder快速创建表单
        return ZBuilder::make('form')
            ->setPageTitle('修改报销单')// 设置页面标题
            ->addFormItems([ // 批量添加表单项
                ['hidden:3','id'],
                ['static:3', 'number', '报销单号',''],
                ['date:3','time','日期','',date('Y-m-d')],
                ['select:3','name', '领用人','',UModel::where('status=1')->column('id,nickname')],
                ['select:3','part', '领用部门','',OModel::where('status=1')->column('id,title')],
                ['text:3','year_money','本年领取金额'],
                ['text:3','money','金额'],
                ['select:3','item','所属项目','',IModel::where('status=1')->column('id,name')],
                ['text:3','maker','经办人','',get_nickname(UID)],
                ['textarea','case','用途'],
                ['textarea','remark','备注'],
                ['file','file','附件'],
            ])
            ->setFormData($data_list)// 设置表单数据
            ->fetch();
    }

    public function delete($record = [])
    {
        return $this->setStatus('delete');
    }

}