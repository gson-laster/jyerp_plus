<?php
namespace app\finance\admin;
use app\admin\controller\Admin;
use app\common\builder\ZBuilder;
use app\finance\model\Finance_stuff as Finance_stuffmodel;
use think\Db;
use app\finance\model\Finance_manager as Finance_managermodel;
/*
 *材料付款
 * */
 class Stuff extends Admin {
	protected $model;
	protected $manager;
	protected $bankInfo;
	protected $bankMinInfo;
    protected function _initialize(){
        parent::_initialize();
        $this -> model = new Finance_stuffmodel();
        $this -> manager = new Finance_managermodel();
        $bankInfo = $this -> manager -> select();
		$arr = [];
		$arrs = [];
		foreach($bankInfo as $v) {
			if($v['status'] == 1) {
//				$arr[$v['id']] = '账户名称:'.$v['name'].', 账号:'.$v['accmount'].', 开户银行:'.$v['bank'];
				$arr[$v['id']] = $v['name'];
			}
			$arrs[$v['id']] = $v['name'];
		}
		$this -> bankInfo = $arr;
		$this -> bankMinInfo = $arrs;
    }
    
 	public function index(){
		$map = $this->getMap();
		$data_list = $this->model -> where($map) -> paginate();
		$arr = ['pay' => 0, 'stock' => 0, 'notpay' => 0];
		foreach($data_list as $v) {
			$arr['pay'] +=  $v['pay'];
			$arr['stock'] +=  $v['stock'];
			$arr['notpay'] +=  $v['notpay'];
		}
				    $js = <<<EOF
            <script type="text/javascript">
                $(function(){
                    $('tbody').append('<tr style="color:#ff0000"><td align="center">总计</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>{$arr["stock"]}</td><td>-</td><td>{$arr["notpay"]}</td><td>{$arr["pay"]}</td><td>-</td><td>-</td></tr>');
                });
            </script>
EOF;
   	$task_list = [
			'title' => '查看详情',
			'icon' => 'fa fa-fw fa-eye',
			'href' => url('edit',['id'=>'__id__'])
		];
		return ZBuilder::make('table')
		  ->addColumns([ // 批量添加列
			[ 'date', '日期', 'date'],
			[ 'number', '付款编号'],
			[ 'name','付款名称'],
//			[ 'type','源单类型'],
//			[ 'source_number','源单号'],
			
			[ 'item','所属项目'],
			[ 'supplier','供应商'],			
			[ 'account','银行账户', $this -> bankMinInfo],			
			[ 'moneyed','已结算金额'],			
			[ 'payed','已支付金额'],			
			[ 'stock','累计入库金额'],			
			[ 'allpay','累计付款金额'],			
			[ 'notpay','未付金额'],			
//			[ 'operator','经办人'],			
			[ 'pay','付款金额'],			
//			[ 'info','(供)账户信息'],			
//			[ 'note','付款说明'],	
	        ['create_time', '创建时间', 'datetime'],
	        ['right_button', '操作','btn'],
	    ])
        ->addTopButton('add') // 添加顶部按钮
		->setPageTitle('材料付款')
		->addRightButtons('delete')
		->addRightButton('edit', $task_list)
		->addTopButton('delete') // 添加顶部按钮
		->setTableName('Finance_stuff') // 指定数据表名
		->setSearch([ 'supplier' => '供应商', 'operator' => '录入人', 'name' => '付款名称', 'item' => '项目名称','number' => '付款编号'], '', '', true) // 设置搜索参数
		->addTimeFilter('date') // 添加时间段筛选
		->setExtraJs($js)
		->setRowList($data_list)
		->fetch();
	
 	}
 		public function add(){
		
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'stuff');
			if(true !== $r) $this -> error($r);
			$data['date'] = strtotime($data['date']);
			$data['number'] = 'CGXJ'.date('Ymdhis',time()).UID;
			
			$this-> model -> create($data);
            $this->success('添加成功', 'index');
		}
		
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['date:3', 'date', '日期'],
//			['text:3', 'number', '付款编号'],
			['text:3', 'name','付款名称'],
			['select:3', 'type','源单类型', '', ['a' => 1, 's' => 2]],
			['text:3', 'source_number','源单号'],
			['select:3', 'item','所属项目', '', ['a', 'b']],
			['select:3', 'supplier','供应商', '', ['a', 'b']],			
			['select:3', 'account','银行账户', '', $this -> bankInfo],			
			['text:3', 'moneyed','已结算金额'],			
			['text:3', 'payed','已支付金额'],			
			['text:3', 'stock','累计入库金额'],			
			['text:3', 'allpay','累计付款金额'],			
			['text:3', 'notpay','未付金额'],			
			['select:3', 'operator','经办人', '', ['a', 'b']],			
			['text:3', 'pay','付款金额'],			
			['text:3', 'info','(供)账户信息'],			
			['textarea:12', 'note','付款说明'],			
		])
		->fetch();
	
	}
	public function edit($id = null){
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'stuff');
			if(true !== $r) $this -> error($r);
			$data['date'] = strtotime($data['date']);
			$this-> model -> where('id', $id) -> update($data);
            $this->success('添加成功', 'index');
		}
		if (null == $id) $this -> error('参数错误');
		$data_list = $this -> model -> where('id', $id) -> find();
		$data_list['date'] = date('Y-m-d', $data_list['date']);
		
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['static:6', 'date', '日期'],
			['static:6', 'number', '付款编号'],
			['static:6', 'name','付款名称'],
			['static:6', 'type','源单类型'],
			['static:6', 'source_number','源单号'],
			['static:6', 'item','所属项目'],
			['static:6', 'supplier','供应商'],			
			['static:6', 'account','银行账户', '', $this -> bankInfo],			
			['static:6', 'moneyed','已结算金额'],			
			['static:6', 'payed','已支付金额'],			
			['static:6', 'stock','累计入库金额'],			
			['static:6', 'allpay','累计付款金额'],			
			['static:6', 'notpay','未付金额'],			
			['static:6', 'operator','经办人'],			
			['static:6', 'pay','付款金额'],			
			['static:6', 'info','(供)账户信息'],			
			['static:12', 'note','付款说明'],	
		])
		-> setPageTitle('详情')
		->hideBtn('submit')
		-> setFormData($data_list)
		->fetch();
	
	}
	public function delete($ids = null){
		if(null == $ids) $this -> error('参数错误');
     	return $this->setStatus('delete');
	}
}