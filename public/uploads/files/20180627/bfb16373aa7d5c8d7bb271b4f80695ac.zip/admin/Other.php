<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/28 0028
 * Time: 14:44
 */

namespace app\finance\admin;


use app\admin\controller\Admin;
use app\common\builder\ZBuilder;
use app\finance\model\Organization;
use app\finance\model\Other as OModel;
use app\finance\model\User as UModel;
use app\finance\model\Item as IModel;
use app\finance\model\Bank as BModel;
use app\finance\model\Pway;
use app\finance\model\Ptype;

class Other extends Admin
{
    public function index(){
        $map = $this->getMap();
        $order = $this->getOrder('o.id desc');
        $data_list = OModel::getList($map,$order);
        //dump($data_list);die;
        //dump($data_list);die;
        //使用ZBuilder构建表格展示数据
        return ZBuilder::make('table')
            ->setSearch(['number'=>'付款编号','objname'=>'项目','time'=>'付款日期','unickname'=>'付款人','o1rtitle'=>'供应商'],'','',true) // 设置搜索框
            ->addTimeFilter('o.time') // 添加时间段筛选
            ->addOrder('number,objname,time,unickname,o1rtitle,maccount,money,pname,pwname,') // 添加排序
            ->addColumns([ // 批量添加列
                ['number', '付款编号'],
                ['objname', '项目'],
                ['date', '付款日期'],
                ['unickname', '付款人'],
                ['ortitle', '部门'],
                ['o1rtitle', '供应商'],
                ['maccount', '公司账户'],
                ['money', '付款金额'],
                ['pname', '付款类型'],
                ['pwname', '付款类型'],
                ['right_button','操作']
            ])
            ->setRowList($data_list) // 设置表格数据
            ->addTopButton('add') //添加删除按钮
            ->addTopButton('delete') //添加删除按钮
//          ->addRightButton('edit') // 添加授权按钮
            ->addRightButton('delete') //添加删除按钮
            ->setTableName('finance_other')
            ->fetch();


    }


    public function add(){
        if ($this->request->isPost()) {
            $data = $this->request->post();
            // 验证
            //            dump($data);die;
            $result = $this->validate($data, 'Other');
            // 验证失败 输出错误信息
            if(true !== $result) $this->error($result);
            $data['number'] = 'FKD'.date('YmdHis',time());
            if ($res = OModel::create($data)) {
                $this->success('新增成功',url('index'));
            } else {
                $this->error('新增失败');
            }
        }



        $list_province= UModel::where('status=1')->column('id,nickname');
        // 使用ZBuilder快速创建表单
        return ZBuilder::make('form')
            ->setPageTitle('付款单')
            ->addFormItems([
                ['date:3','date','日期','',date('Y-m-d')],
                ['Linkage:3','payer', '付款人','',$list_province,'',url('get_part'),'part'],
                ['select:3','part', '部门'],
                ['select:3','supplier','供应商','',IModel::where('status=1')->column('id,name')],
                ['select:3','account','公司账户','',BModel::where('status=1')->column('id,name')],
                ['text:3','money','付款金额'],
                ['select:3','ptype','付款类型','',Ptype::where('status=1')->column('id,name')],
                ['select:3','pway','支付方式','',Pway::where('status=1')->column('id,name')],
                ['text:3','maker','经办人','',get_nickname(UID)],
                ['select:3','item','项目','',IModel::where('status=1')->column('id,name')],
                ['textarea','remark','付款说明'],
                ['file','file','附件'],
            ])
            ->fetch();
    }

    public function get_part($payer=''){
        $res= UModel::where('id',$payer)->select();
        //dump($res);die;
        $array =array();
        foreach($res as $key=>$val){
            $array[] = ['key'=>$val['id'],'value'=>UModel::getOne(($val['organization']))];
        }
        $arr['code'] = '1'; //判断状态
        $arr['msg'] = '请求成功'; //回传信息
        $arr['list'] =$array; //数据
        return json($arr);
    }




    public function delete($record = [])
    {
        return $this->setStatus('delete');
    }

}