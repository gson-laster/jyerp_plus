<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/28 0028
 * Time: 09:25
 */

namespace app\finance\admin;
use app\admin\controller\Admin;
use app\finance\model\Item;
use app\finance\model\Pay as PayModel;
use app\common\builder\ZBuilder;
use app\finance\validate\Pay as PayValidate;
use app\finance\model\Organization as OModel;
use app\finance\model\Item as IModel;
use app\finance\model\Bank as BModel;
class Pay extends Admin
{

    /*
     * 租赁付款管理
     */
    public function  index(){
            $map = $this->getMap();
            $order = $this->getOrder('h.id desc');
            $data_list = PayModel::getList($map,$order);

            //dump($data_list);die;
            //dump($data_list);die;
            //使用ZBuilder构建表格展示数据
            return ZBuilder::make('table')
                ->setSearch(['maker'=>'填报人','iname'=>'供应商','sname'=>'项目'],'','',true) // 设置搜索框
                ->addTimeFilter('finance_hire.date') // 添加时间段筛选
                ->addOrder('id,number,name,maker,date,sname,money,iname') // 添加排序
                ->addColumns([ // 批量添加列
                    ['number', '付款编号'],
                    ['name', '付款名称'],
                    ['maker', '填报人'],
                    ['date', '日期'],
                    ['iname', '供应商'],
                    ['money', '报销金额'],
                    ['sname', '所属项目'],
                    ['right_button','操作']
                ])
                ->setRowList($data_list) // 设置表格数据
                ->addTopButton('add') //添加删除按钮
                ->addTopButton('delete') //添加删除按钮
               // ->addRightButton('edit') // 添加授权按钮
                ->addRightButton('delete') //添加删除按钮
                ->setTableName('finance_hire')
                ->fetch();
    }

    /*
     * 申请租赁付款
     */
    public function add(){
        if ($this->request->isPost()) {
            $data = $this->request->post();
            // 验证

            //            dump($data);die;
            $res=$this->request->post('pact');
            $result = $this->validate($data, 'Pay');
            // 验证失败 输出错误信息
            if(true !== $result) $this->error($result);
            $data['number'] = 'ZL'.date('YmdHis',time());
            if ($res = PayModel::create($data)) {
                $this->success('新增成功',url('index'));
            } else {
                $this->error('新增失败');
            }
        }



        $list_province= BModel::where('status=1')->column('id,bank');
        // 使用ZBuilder快速创建表单
        return ZBuilder::make('form')
            ->setPageTitle('租赁付款申请')
            ->addFormItems([
                ['date:3','date','日期','',date('Y-m-d')],
                ['text:3','name', '付款名称'],
                ['select:3','pact', '租赁合同','',OModel::where('status=1')->column('id,title')],
                ['select:3','item','所属项目','',IModel::where('status=1')->column('id,name')],
                ['select:3','supplier','供应商','',IModel::where('status=1')->column('id,name')],
                ['Linkage:3','bank_name','开户行名称','',$list_province,'',url('get_account'),'account'],
                ['select:3','account','银行账户'],
                ['text:3','money','付款金额'],
                ['text:3','maker','填报人','',get_nickname(UID)],
                ['textarea','remark','付款说明'],
                ['file','file','附件'],
            ])
            ->fetch();
    }

    public function get_account($bank_name=''){
        $res= BModel::where('id',$bank_name)->select();
        //dump($res);die;
        $array =array();
        foreach($res as $key=>$val){
            $array[] = ['key'=>$val['id'],'value'=>$val['account']];
        }

        $arr['code'] = '1'; //判断状态
        $arr['msg'] = '请求成功'; //回传信息
        $arr['list'] =$array; //数据
        return json($arr);
    }


    /*
     * 租赁付款申请
     */

    /*
     * 租赁付款删除
     */


    public function delete($record = []){
        return $this->setStatus('delete');
        }
}