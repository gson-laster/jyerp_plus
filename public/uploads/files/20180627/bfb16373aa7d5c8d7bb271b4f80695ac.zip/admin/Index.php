<?php
namespace app\finance\admin;
use app\admin\controller\Admin;
use app\common\builder\ZBuilder;
use app\finance\model\Finance_manager as finance_managerModel;
use think\Db;
/*
 账户信息
 * */
class Index extends Admin {
	protected $finance_manager;
    protected function _initialize(){
        parent::_initialize();
        $this->finance_manager = new finance_managerModel();
    }
	public function Index(){
		$map = $this->getMap();
		$data_list = $this->finance_manager -> where($map) -> paginate();
		return ZBuilder::make('table')
		  ->addColumns([ // 批量添加列
//	        ['id', 'id'],
	        ['name', '账户名称'],
	        ['accmount', '账户'],
	        ['bank', '开户银行'],
	        ['address', '地址'],
	        ['date', '开户日期', 'date'],
	        ['operator', '经办人'],
	        ['ismoneyaccount', '是否现金用户', ['否', '是']],

	        ['status', '是否停用', 'switch'],
	        ['note', '备注'],
	        ['create_time', '创建时间', 'datetime'],
	        ['right_button', '操作','btn'],
	    ])
        ->addTopButton('add') // 添加顶部按钮
		->setPageTitle('账户信息')
		->addRightButtons('edit,delete')
		->addTopButton('delete') // 添加顶部按钮
		->setTableName('finance_manager') // 指定数据表名
		->setSearch(['accmount' => '账户', 'operator' => '经办人', 'name' => '账户名称','bank' => '开户银行'], '', '', true) // 设置搜索参数
		->addTimeFilter('date') // 添加时间段筛选
		->setRowList($data_list)
		->fetch();
	}
	public function add(){
		
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'Index');
			if(true !== $r) $this -> error($r);
			$data['date'] = strtotime($data['date']);
			$this-> finance_manager -> create($data);
            $this->success('添加成功', 'index');
		}
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['text:6', 'name', '账户名称'],
			['text:6', 'accmount','账户'],
			['text:6', 'bank','开户银行'],
			['text:6', 'address','地址'],
			['date:6', 'date','开户日期'],
			['text:6', 'operator','经办人'],			
			['radio:6', 'ismoneyaccount','是否现金用户', '', ['否', '是']],			
			['radio:6', 'status','是否启用', '', ['否', '是']],			
			['textarea','note','备注'],
		])
		->fetch();
	
	}
	public function edit($id = null){
		if($this -> request -> ispost()){
			$data = $this -> request ->post();
			$r = $this -> Validate($data, 'Index');
			if(true !== $r) $this -> error($r);
			$data['date'] = strtotime($data['date']);
			$this-> finance_manager -> where('id', $id) -> update($data);
            $this->success('添加成功', 'index');
		}
		if (null == $id) $this -> error('参数错误');
		$data_list = $this -> finance_manager -> where('id', $id) -> find();
		
		return ZBuilder::make('form')
		->addFormItems([
		// 批量添加表单项
			['text:6', 'name', '账户名称'],
			['text:6', 'accmount','账户'],
			['text:6', 'bank','开户银行'],
			['text:6', 'address','地址'],
			['date:6', 'date','开户日期'],
			['text:6', 'operator','经办人'],			
			['radio:6', 'ismoneyaccount','是否现金用户', '', ['否', '是']],			
			['radio:6', 'status','是否启用', '', ['否', '是']],			
			['textarea','note','备注'],
		])
		-> setFormData($data_list)
		->fetch();
	
	}
	public function delete($ids = null){
		if(null == $ids) $this -> error('参数错误');
     	return $this->setStatus('delete');
	}
}
