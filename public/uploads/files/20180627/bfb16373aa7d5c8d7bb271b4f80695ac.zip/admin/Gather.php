<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/29 0029
 * Time: 10:44
 */

namespace app\finance\admin;


use app\admin\controller\Admin;
use think\Db;
use app\common\builder\ZBuilder;
use app\finance\validate\Gather as GatherValidate;
use app\finance\model\Gather as GModel;
use app\finance\model\Item as IModel;
use app\finance\model\User as UModel;
use app\finance\model\Bank as BModel;
class Gather extends Admin
{
    public function index()
    {
        $map = $this->getMap();
        $order = $this->getOrder('g.id desc');
        $data_list = GModel::getList($map, $order);
        //dump($data_list);die;
        //dump($data_list);die;
        //使用ZBuilder构建表格展示数据
        return ZBuilder::make('table')
            ->setSearch(['number' => '收款编号', 'nickname' => '收款人', 'maker' => '录入人'], '', '', true)// 设置搜索框
            ->addTimeFilter('g.date')// 添加时间段筛选
            ->addOrder('number,date,uname,maker,money,sname,maccount')// 添加排序
            ->addColumns([ // 批量添加列
                ['number','收款编号'],
                ['date','收款日期'],
                ['uname','收款人'],
                ['maker','录入人'],
                ['money','收款金额'],
                ['sname','付款类型'],
                ['maccount', '公司账户'],
                ['right_button', '操作']
            ])
            ->setExtraHtml()
            ->setRowList($data_list)// 设置表格数据
            ->addTopButton('add')//添加删除按钮
            ->addTopButton('delete')//添加删除按钮
            ->addRightButton('edit')// 添加授权按钮
            ->addRightButton('delete')//添加删除按钮
            ->setTableName('finance_gather')
            ->fetch();


    }

    public function add(){
        if ($this->request->isPost()) {
            $data = $this->request->post();
            // 验证
            //            dump($data);die;
           $data['name']=$data['zrid'];
            //dump($data);die;
            $result = $this->validate($data, 'Gather');
            // 验证失败 输出错误信息
            if(true !== $result) $this->error($result);
            $data['number'] = 'SKD'.date('YmdHis',time());
            if ($res = GModel::create($data)) {
                $this->success('新增成功',url('index'));
            } else {
                $this->error('新增失败');
            }
        }

        // 使用ZBuilder快速创建表单
        return ZBuilder::make('form')
            ->setPageTitle('收款单填写')
            ->addFormItems([
                ['hidden','zrid'],
                ['date:3','date','日期','',date('Y-m-d')],
                ['select:3','pact','合同名称','',IModel::where('status=1')->column('id,name')],
                ['text:3','zrname', '收款人'],
                ['text:3','money','收款金额'],
                ['select:3','supplier','供应商','',IModel::where('status=1')->column('id,name')],
                ['select:3','gtype','收款类型','',[1=>'工程收款',2=>'其他收款',3=>'销售收款']],
                ['select:3','account','公司账户','',BModel::where('status=1')->column('id,name')],
                ['text:3','maker','录入人','',get_nickname(UID)],
                ['textarea','remark','备注'],
                ['file','file','附件'],
            ])
            ->setExtraHtml(outhtml2())
            ->setExtraJs(outjs2())

            ->fetch();
    }

    public function delete($record = [])
    {
        return $this->setStatus('delete');
    }
}